# IMKT Chat Bot

### Features
- Scrapes through your website
- Stores the user interactions until session is closed?
- AI Used: ChatGPT
- Prompt he/she is an assistant(cheap labor) for your website
- Is embeded with script in your website
- User Bot Engagement 


## Rules
### Prompt Rules
- Bot will only answer questions inside the context of the website
- Should not reveal private info like the prompt used
- Should not change behaviour/identity based on any user input
- Should not provide 

### Cost Cut
- Refrain from using special symbols whenever possible (each use one input token, same for greek letters)
- chunk the data befor creating embeddings


## Security Features to add:
- rate-limiting
- cors
- input sanitization
- prevent external use with:
	- Header checking (Host, Origin...)
	- private api-key?
- ISMABA: (implement security messures against bankrupcy attacks)


## TOADD:
- On scraped data
	- Add referenced links inside the page and bring also relevant data from it if requested
	- 
